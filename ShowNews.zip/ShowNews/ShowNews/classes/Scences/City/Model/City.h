//
//  City.h
//  ShowNews
//
//  Created by LK on 16/6/26.
//  Copyright © 2016年 YZZL. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface City : NSObject
@property (nonatomic, strong) NSString *pinyin;
@property (nonatomic, strong) NSString *city;
@property (nonatomic, strong) NSString *Id;
@end
