//
//  SetCell.m
//  ShowNews
//
//  Created by ZZQ on 16/6/30.
//  Copyright © 2016年 YZZL. All rights reserved.
//

#import "SetCell.h"

@implementation SetCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
