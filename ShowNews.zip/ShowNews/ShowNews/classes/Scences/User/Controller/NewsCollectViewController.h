//
//  NewsCollectViewController.h
//  ShowNews
//
//  Created by ZZQ on 16/7/1.
//  Copyright © 2016年 YZZL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsCollectViewController : UINavigationController

@end
