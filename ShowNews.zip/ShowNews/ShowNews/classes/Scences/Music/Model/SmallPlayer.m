//
//  SmallPlayer.m
//  ShowNews
//
//  Created by ZZQ on 16/6/27.
//  Copyright © 2016年 YZZL. All rights reserved.
//

#import "SmallPlayer.h"

@interface SmallPlayer ()








@end

@implementation SmallPlayer

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/









@end
