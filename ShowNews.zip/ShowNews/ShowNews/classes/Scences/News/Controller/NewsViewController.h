//
//  NewsViewController.h
//  ShowNews
//
//  Created by YYP on 16/6/25.
//  Copyright © 2016年 YZZL. All rights reserved.
//

#import "BaseViewController.h"

@interface NewsViewController : BaseViewController

@end
