//
//  NewsPhotoSetDetailViewController.h
//  ShowNews
//
//  Created by YYP on 16/6/29.
//  Copyright © 2016年 YZZL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "News.h"
@interface NewsPhotoSetDetailViewController : UIViewController
@property (nonatomic, strong) News *news;
@end
