//
//  NewsListViewController.h
//  ShowNews
//
//  Created by YYP on 16/6/29.
//  Copyright © 2016年 YZZL. All rights reserved.
//

#import "BaseViewController.h"
#import "News.h"

@interface NewsSpecialListViewController : BaseViewController
@property (nonatomic, strong) News *news;
@end
