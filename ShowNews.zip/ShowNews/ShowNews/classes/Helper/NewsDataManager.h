//
//  NewsDataManager.h
//  ShowNews
//
//  Created by YYP on 16/6/27.
//  Copyright © 2016年 YZZL. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsDataManager : NSObject

@end
