//
//  Weather.h
//  ShowNews
//
//  Created by YYP on 16/6/25.
//  Copyright © 2016年 YZZL. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Weather : NSObject
//@property (nonatomic, copy) NSString *
@end
