//
//  UILabel+Font.h
//  啊啊啊啊啊啊啊啊
//
//  Created by ZZQ on 16/6/24.
//  Copyright © 2016年 ZZQ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
@interface UILabel (Font)

@end
