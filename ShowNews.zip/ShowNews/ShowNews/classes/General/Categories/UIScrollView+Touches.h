//
//  UIScrollView+Touches.h
//  ShowNews
//
//  Created by YYP on 16/6/20.
//  Copyright © 2016年 YZZL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (Touches)

@end
